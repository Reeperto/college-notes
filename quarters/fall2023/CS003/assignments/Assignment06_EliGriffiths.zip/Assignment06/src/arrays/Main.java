// Name: Eli Griffiths
// Assignment #6 : 1D Arrays
// Due Date: 10/6/23

package arrays;

public class Main {
	public static void main(String[] args) {
		int[] numbers = new int[1000];

		// Populate numbers with random integers from 1 - 100
		for (int i = 0; i < numbers.length; ++i) {
			numbers[i] = (int) (Math.random() * 100) + 1;
		}

		System.out.println(String.format("The average of the numbers is %.2f", CalculateAverage(numbers)));
		CountOccurences(numbers);
	}

	public static double CalculateAverage(int[] data) {
		int accumulator = 0;
		for (int number : data) {
			accumulator += number;
		}
		return accumulator / (double) data.length;
	}
	
	public static void CountOccurences(int[] data)
	{
		int[] counts = new int[100];
		for (int number : data)
		{
			counts[number - 1] += 1;
		}
		
		for (int i = 0; i < 100; ++i)
		{
			System.out.println("The number " + (i+1) + " appears " + counts[i] + " times.");
		}
	}
}
