package assignment;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class Main extends Application {
	public static final double WIDTH = 280;
	public static final double HEIGHT = 300;
	public static final double PADDING = 10;

	@Override // Override the start method in the Application class
	public void start(Stage primaryStage) throws Exception {
		double sum = 0;

		Pane pane = new Pane();
		var children = pane.getChildren();

		//@formatter:off
		String[] ids = { 
			"7", "8", "9", "÷", 
			"4", "5", "6", "×",
			"1", "2", "3", "-",
			"0", ".", "+", "="
		};
		//@formatter:on

		double button_grid_width = WIDTH - 2 * PADDING;
		double button_grid_height = HEIGHT - 5 * PADDING;
		double button_size = (button_grid_width - 4 * PADDING) / 4.0;

		for (int i = 0; i < ids.length; ++i) {
			Button button = new Button(ids[i]);

			button.setPrefSize(button_size, button_size);
			button.setLayoutX(PADDING + (button_grid_width / 4.0) * (i % 4));
			button.setLayoutY(5 * PADDING + (button_grid_height / 4.0) * (i / 4));

			children.add(button);
		}

		Label myLabel = new Label("123456");

		myLabel.setFont(Font.font("Courier", FontWeight.BOLD, FontPosture.REGULAR, 20));
		myLabel.setStyle("-fx-border-color: blue;");
		myLabel.setAlignment(Pos.BASELINE_RIGHT); // align text to the right side of the label.
		myLabel.setLayoutX(PADDING); // set the x location of the label
		myLabel.setLayoutY(PADDING); // set the y location of the label
		myLabel.setPrefSize(WIDTH - 2 * PADDING, 20); // set the width and height of the label
		myLabel.setText(Double.toString(sum));

		children.add(myLabel);

		Scene scene = new Scene(pane, WIDTH, HEIGHT);
		primaryStage.setTitle("Calculator"); // Set the stage title
		primaryStage.setScene(scene); // Place the scene in the stage
		primaryStage.setResizable(false); // Maintain the calculator size
		primaryStage.show(); // Display the stage
	}

	public static void main(String[] args) {
		launch(args);
	}
}
