package MyPackage;

import java.util.Scanner;

public class MyClass {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Please enter an integer: ");
		long user_int = scan.nextLong();
		System.out.println("The sum of the digits is: " + sumDigits(user_int));
	}
	
	public static int sumDigits(long n) {
		int accumulator = 0;
		
		if (n < 0) n *= -1;

		while (n != 0) {
			accumulator += n % 10;
			n /= 10;
		}
		
		return accumulator;
	}
}
