package MyPackage;

import java.io.BufferedReader;
import java.io.InputStreamReader;

// # How to classify the riders:
//
// If a person is younger than or equal to 10 years old and weights less than 80 pounds print the following:
// This person needs to ride the black roller coaster.
// 
// If a person is younger than or equal to 10 years old and weights between 80 and 200 pounds (including weighing exactly 80 or 200 pounds), print the following:
// This person needs to ride the green roller coaster.
// 
// If a person is younger than or equal to 10 years old and weights more than 200 pounds, print the following:
// This person needs to ride the yellow roller coaster.
// 
// If a person is younger than or equal to 20 years old but older than 10 and weights less than 80 pounds, print the following:
// This person needs to ride the silver roller coaster.
// 
// If a person is younger than or equal to 20 years old but older than 10 and weights between 80 and 200 pounds (including weighting exactly 80 or 200 pounds), print
// This person needs to ride the red roller coaster.
// 
// if a person is younger than or equal to 20 years old but older than 10 and weights more than 200 pounds, print:
// This person needs to ride the purple roller coaster.
// 
// Everyone else rides the pink roller coaster

public class MyClass {
	static BufferedReader reader;
	static int age;
	static int weight;

	public static void main(String[] args) {
		reader = new BufferedReader(new InputStreamReader(System.in));

		while (!GetUserInfo()) {
			System.out.println("Error in input. Please try again.");
		}

		if (age <= 10) {
			if (weight < 80) {
				System.out.println("This person needs to ride the black roller coaster.");
			} else if (weight >= 80 && weight < 200) {
				System.out.println("This person needs to ride the green roller coaster.");
			} else if (weight > 200) {
				System.out.println("This person needs to ride the yellow roller coaster.");
			}
		} else if (age > 10 && age <= 20) {
			if (weight < 80) {
				System.out.println("This person needs to ride the silver roller coaster.");
			} else if (weight >= 80 && weight < 200) {
				System.out.println("This person needs to ride the red roller coaster.");
			} else if (weight > 200) {
				System.out.println("This person needs to ride the purple roller coaster.");
			}
		} else {
			System.out.println("This person needs to ride the pink roller coaster.");
		}

	}

	public static Boolean GetUserInfo() {
		try {
			System.out.print("Please enter your age: ");
			age = Integer.parseInt(reader.readLine());

			if (age <= 0)
				return false;

			System.out.print("Please enter your weight in pounds: ");
			weight = Integer.parseInt(reader.readLine());

			if (weight <= 0)
				return false;

		} catch (Exception ignore) {
			return false;
		}

		return true;
	}
}
