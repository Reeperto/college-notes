// Eli Griffiths
// 9/21/23
// Assignment Draw Something
// link to resources you used or prompts you used with chatGPT or phind.com

package package_01;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

import javax.swing.JFrame;

public class DrawRectangle extends JFrame {

	int[] x_tri = {0, 400, 200}; 
	int[] y_tri = {400, 400, 0};
	int max_order = 10;
	Color[] colors = {
			Color.BLACK,
			Color.BLUE,
			Color.RED,
			Color.YELLOW,
			Color.GREEN,
			Color.MAGENTA
			};

    public DrawRectangle() {
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
    
    public Point Midpoint(Point p1, Point p2)
    {
    	return new Point(
    		(p1.x + p2.x) / 2, (p1.y + p2.y) / 2
    	);
    }
    
    public void RecursiveTriangleDraw(Graphics g, int order, Point p1, Point p2, Point p3)
    {
    	if (order == 0)
    	{
    		int color_index = (int) (Math.random() * (colors.length - 1));
    		g.setColor(colors[color_index]);
    		g.drawLine(p1.x, p1.y, p2.x, p2.y);
    		g.drawLine(p2.x, p2.y, p3.x, p3.y);
    		g.drawLine(p3.x, p3.y, p1.x, p1.y);
    	} else {
    		Point mid12 = Midpoint(p1, p2);
    		Point mid23 = Midpoint(p2, p3);
    		Point mid31 = Midpoint(p3, p1);
    		
    		RecursiveTriangleDraw(g, order - 1, p1, mid12, mid31);
    		RecursiveTriangleDraw(g, order - 1, mid12, p2, mid23);
    		RecursiveTriangleDraw(g, order - 1, mid31, mid23, p3);
    	}
    }
    
    public void paint(Graphics g) {
       	super.paint(g);
        Point p1 = new Point(200,0);
        Point p2 = new Point(400,400);
        Point p3 = new Point(0,400);

        RecursiveTriangleDraw(g, max_order, p1, p2, p3);
        
    }

    public static void main(String[] args) {
        new DrawRectangle();
    }
}