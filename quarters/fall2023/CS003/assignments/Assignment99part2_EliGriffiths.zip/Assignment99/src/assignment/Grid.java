package assignment;

import java.awt.Graphics;

import javax.swing.JFrame;

public class Grid extends JFrame {
	int padding = 50;
	int width = 400 - 2 * padding;
	int height = 400 - 2 * padding;

	int spacing;
	int grid_count;

	public Grid() {}

	public void DrawGrid(int n) {
		grid_count = n;
		spacing = width / n;

		setSize(400, 400);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}

	public void paint(Graphics g) {
		for (int i = 0; i <= grid_count; i++) {
			g.drawLine(i * spacing + padding, padding, i * spacing + padding, height + padding);
		}

		for (int j = 0; j <= grid_count; j++) {
			g.drawLine(padding, j * spacing + padding, width + padding, j * spacing + padding);
		}

	}
}