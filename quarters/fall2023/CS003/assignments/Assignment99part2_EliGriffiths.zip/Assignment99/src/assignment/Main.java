package assignment;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		var scan = new Scanner(System.in);

		System.out.println("""
		1. Task 1
		2. Task 2
		3. Task 3
		4. Task 4
		-1 to quit.""");
		
		int userChoice = scan.nextInt();
		
		if (userChoice == -1)
		{
			System.out.println("Quitting. Thank you.");
			scan.close();
			return;
		}
		
		if (userChoice == 1)
		{
			Grid grid = new Grid();
			System.out.print("Enter an integer greater than 5: ");
			grid.DrawGrid(scan.nextInt());
		}
		
		scan.close();
		
	}
}
