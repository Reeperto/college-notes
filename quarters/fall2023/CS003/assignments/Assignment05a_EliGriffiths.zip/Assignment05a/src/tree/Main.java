package tree;

public class Main {

	public static void DrawTree() {
		int max_width = 13;

		for (int i = 1; i <= max_width; i += 2) {
			for (int j = 0; j < (max_width - i) / 2; j++) {
				System.out.print(' ');
			}

			for (int k = 0; k < i; k++) {
				System.out.print('*');
			}

			System.out.print('\n');
		}

		for (int i = 1; i <= (max_width - 1) / 2; i++) {
			System.out.print(' ');
		}

		System.out.println('|');

	}

	public static void main(String[] args) {
		DrawTree();
	}

}
