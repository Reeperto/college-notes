package assignment;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JFrame;

public class Grid extends JFrame {
	int padding = 50;
	int width = 400 - 2 * padding;
	int height = 400 - 2 * padding;

	int spacing;
	int grid_count;
	
	int[][] array;

	Grid() {}

	public void DrawGrid(int n) {
		
		array = new int[n][n];
		
		for (int i = 0; i < n; ++i)
		{
			for (int j = 0; j < n; ++j)
			{
				array[i][j] = (i + j + 1) % 2;
			}
		}
		
		grid_count = n;
		spacing = width / n;

		setSize(400, 400);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}

	public void paint(Graphics g) {
		g.setColor(Color.BLACK);
		g.drawRect(padding, padding, width, height);
		for (int i = 0; i < grid_count; i++) {
			for (int j = 0; j < grid_count; j++) {
				if (array[i][j] == 1)
				{
					g.fillRect(i * spacing + padding, j * spacing + padding, spacing, spacing);
				} else {
					g.drawRect(i * spacing + padding, j * spacing + padding, spacing, spacing);
				}
			}
		}
	}
}