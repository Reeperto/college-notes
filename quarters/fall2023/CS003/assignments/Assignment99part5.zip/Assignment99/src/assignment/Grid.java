package assignment;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.WindowEvent;
import java.util.concurrent.TimeUnit;

import javax.swing.JFrame;

@SuppressWarnings("serial")
public class Grid extends JFrame {
	int window_padding = 50;
	int window_width = 400 - 2 * window_padding;
	int window_height = 400 - 2 * window_padding;

	int spacing;
	int grid_count;

	int[][] previous_generation;
	int[][] current_generation;

	Grid(int size) {
		SetGrid(size);
		
		addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				GameLoader.GridToState("out_state.txt", (Grid) e.getSource());
			}
		});
	}

	private int Mod(int pos) {
		return ((pos % grid_count) + grid_count) % grid_count;
	}
	
	public void SetGrid(int size) {
		previous_generation = new int[size][size];
		current_generation = new int[size][size];
		grid_count = size;
		spacing = window_width / size;
	}

	public void DrawGrid() {
		setSize(400, 400);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		
		while (true) {
			try {
				TimeUnit.MILLISECONDS.sleep(200);
			} catch (InterruptedException e) {}
			repaint();
			AdvanceGeneration();
		}
		
	}

	private void AdvanceGeneration() {
		int neighbors;
		int current_cell;

		for (int i = 0; i < grid_count; ++i) {
			for (int j = 0; j < grid_count; ++j) {
				current_cell = previous_generation[i][j];
				neighbors = 0;

				neighbors += previous_generation[Mod(i - 1)][Mod(j - 1)];
				neighbors += previous_generation[Mod(i - 1)][Mod(j)];
				neighbors += previous_generation[Mod(i - 1)][Mod(j + 1)];

				neighbors += previous_generation[Mod(i)][Mod(j - 1)];
				neighbors += previous_generation[Mod(i)][Mod(j + 1)];

				neighbors += previous_generation[Mod(i + 1)][Mod(j - 1)];
				neighbors += previous_generation[Mod(i + 1)][Mod(j)];
				neighbors += previous_generation[Mod(i + 1)][Mod(j + 1)];

				
				if (current_cell == 1) {
					if (neighbors == 2 || neighbors == 3) {
						current_generation[i][j] = 1;
					} else {
						current_generation[i][j] = 0;
					}
				} else {
					if (neighbors == 3) {
						current_generation[i][j] = 1;
					} else {
						current_generation[i][j] = 0;
					}
				}

			}
		}
		
		for (int i = 0; i < grid_count; ++i) {
			for (int j = 0; j < grid_count; ++j) {
				previous_generation[i][j] = current_generation[i][j];
			}
		}
	}

	public void paint(Graphics g) {
		g.setColor(Color.WHITE);
		g.clearRect(window_padding, window_padding, window_width, window_height);
		g.setColor(Color.BLACK);
		g.drawRect(window_padding, window_padding, window_width, window_height);
		for (int i = 0; i < grid_count; i++) {
			for (int j = 0; j < grid_count; j++) {
				if (previous_generation[i][j] == 1) {
					g.fillRect(i * spacing + window_padding, j * spacing + window_padding, spacing, spacing);
				} else {
					g.drawRect(i * spacing + window_padding, j * spacing + window_padding, spacing, spacing);
				}
			}
		}
	}
}